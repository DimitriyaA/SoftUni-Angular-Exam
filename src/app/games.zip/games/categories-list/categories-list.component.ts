import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from '../../shared/loader/loader.component';

@Component({
  selector: 'app-categories-list',
  standalone: true,
  imports: [CommonModule, LoaderComponent], // Include CommonModule and loader component
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.css']
})
export class CategoriesListComponent implements OnInit {
  isLoading = true;
  games = [
    { name: 'Game 1', description: 'A fun game', picture: 'game1.jpg', condition: 'New', price: 10, category: 'Card Games' },
    { name: 'Game 2', description: 'An adventure game', picture: 'game2.jpg', condition: 'Used', price: 15, category: 'Adventure Games' },
    { name: 'Game 3', description: 'A family game', picture: 'game3.jpg', condition: 'New', price: 20, category: 'Family Games' },
    { name: 'Game 4', description: 'Strategic gameplay', picture: 'game4.jpg', condition: 'Used', price: 25, category: 'Strategy Games' },
    { name: 'Game 5', description: 'For children', picture: 'game5.jpg', condition: 'New', price: 5, category: 'Children\'s Games' },
    { name: 'Game 6', description: 'A second card game', picture: 'game6.jpg', condition: 'Used', price: 12, category: 'Card Games' },
    // Add more mock games as needed
  ];
  categorizedGames: { [key: string]: any[] } = {};

  ngOnInit() {
    this.groupGamesByCategory();
    this.simulateLoading();
  }

  groupGamesByCategory() {
    const categories = ['Children\'s Games', 'Card Games', 'Adventure Games', 'Family Games', 'Strategy Games'];

    categories.forEach(category => {
      // Filter and get the last 5 games in each category
      this.categorizedGames[category] = this.games
        .filter(game => game.category === category)
        .slice(-5);
    });

    console.log('Categorized Games:', this.categorizedGames);
  }

  simulateLoading() {
    setTimeout(() => {
      this.isLoading = false; // Loading ends after 5 seconds
    }, 1000);
  }
}
