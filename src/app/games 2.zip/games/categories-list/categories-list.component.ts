import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from '../../shared/loader/loader.component';

@Component({
  selector: 'app-categories-list',
  standalone: true,
  imports: [CommonModule, LoaderComponent], // Include LoaderComponent and CommonModule
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.css']
})
export class CategoriesListComponent implements OnInit {
  isLoading = true; // Loading state
  games = [
    { name: 'Game 1', description: 'A fun game with many features to explore.', picture: 'game1.jpg', condition: 'New', price: 10, category: 'Card Games' },
    { name: 'Game 2', description: 'An exciting adventure game.', picture: 'game2.jpg', condition: 'Used', price: 15, category: 'Adventure Games' },
    { name: 'Game 3', description: 'A great game for family time.', picture: 'game3.jpg', condition: 'New', price: 20, category: 'Family Games' },
    { name: 'Game 4', description: 'Strategic gameplay for advanced players.', picture: 'game4.jpg', condition: 'Used', price: 25, category: 'Strategy Games' },
    { name: 'Game 5', description: 'Perfect for children to enjoy.', picture: 'game5.jpg', condition: 'New', price: 5, category: 'Children\'s Games' },
    { name: 'Game 6', description: 'Another card game for enthusiasts.', picture: 'game6.jpg', condition: 'Used', price: 12, category: 'Card Games' },
    // Add more mock games for testing
  ];
  categories = ['Children\'s Games', 'Card Games', 'Adventure Games', 'Family Games', 'Strategy Games']; // Predefined categories
  lastFiveGames: any[] = [];

  ngOnInit() {
    this.loadLastFiveGames();
    this.simulateLoading();
  }

  loadLastFiveGames() {
    // Get the last 5 games regardless of category
    this.lastFiveGames = this.games.slice(-5);
    console.log('Last 5 Games:', this.lastFiveGames);
  }

  simulateLoading() {
    setTimeout(() => {
      this.isLoading = false; // Stop loading after 5 seconds
    }, 1000);
  }
}
